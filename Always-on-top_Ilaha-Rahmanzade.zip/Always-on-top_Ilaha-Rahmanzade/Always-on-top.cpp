#include <iostream>
#include <windows.h>
#include <thread>
#include <chrono>

using namespace std;

void KeepNotepadOnTop(HWND hwnd) {
    while (true) {
        if (IsWindow(hwnd)) {
            SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
            if (IsIconic(hwnd)) {
                ShowWindow(hwnd, SW_RESTORE);
            }
        } else {
            cout << "Notepad window closed!" << endl;
            break;
        }
        this_thread::sleep_for(chrono::milliseconds(100));
    }
}

int main() {
    string filename;
    cout << "Enter the Notepad window title (e.g., Ilaha.txt - Notepad): ";
    getline(cin, filename);

    HWND hwnd = FindWindow(NULL, filename.c_str());

    if (hwnd == NULL) {
        cout << "Notepad window not found!" << endl;
        return 1;
    }

    cout << "Notepad window is now set to stay always on top." << endl;

    thread t(KeepNotepadOnTop, hwnd);

    cout << "Press Enter to exit..." << endl;
    cin.get();

    t.detach();
    return 0;
}
